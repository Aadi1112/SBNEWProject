package com.aadi;

public class Laptop {
	
	public Laptop(String name) {
		// TODO Auto-generated constructor stub
	}

	void start() {
		
		System.out.println("Laptop is started...");
	}
}