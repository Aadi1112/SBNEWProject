package com.aadi;

public class Tab  {

	public Tab(String name) {
		// TODO Auto-generated constructor stub
	}
	void start() {
		
		System.out.println("Tab is started");
	}
	
	
}
