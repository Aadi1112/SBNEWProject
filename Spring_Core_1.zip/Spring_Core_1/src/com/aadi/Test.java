package com.aadi;

public class Test {

	public static void main(String[] args) {
		
		//Student s1=new Student(new Laptop("Lenevo"),new Tab("IPAD"));
		
		Student s1=new Student();
		
//		s1.laptop=new Laptop("lenevo");
//		s1.tab=new Tab("Ipad");
		
		s1.setLaptop(new Laptop("lenevo"));
		s1.setTab(new Tab("Ipad"));
		s1.study();
	}
}
